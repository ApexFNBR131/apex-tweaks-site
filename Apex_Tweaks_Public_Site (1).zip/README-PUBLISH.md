# Apex Tweaks — public website package

## What's included
- `website/index.html` — responsive dark/purple landing page.
- `website/Apex_Tweaks_Release_Package.zip` — current release package with source and Windows build files.

The download buttons currently download the ZIP package. The ZIP does **not** contain a ready-built `.exe`.

## Publish for free with GitHub Pages
1. Sign in to GitHub and create a **public** repository, e.g. `apex-tweaks-site`.
2. Upload the two files from the `website` folder (`index.html` and `Apex_Tweaks_Release_Package.zip`) to the repository root.
3. Open **Settings → Pages**.
4. Under Build and deployment, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
5. Wait for GitHub Pages to publish the site. Its public URL will be shown on the Pages settings screen.
6. Open that URL in a private/incognito window and test both download buttons.

## To publish a ready-to-run Windows EXE
1. On Windows 10/11, extract the release ZIP and run `Build EXE on Windows.bat` as described in `PUBLISHING.md`.
2. Test `dist\\ApexTweaks.exe` on a clean Windows machine.
3. Upload the EXE to a GitHub Release (or put it in the website folder).
4. Update both download button links in `index.html` to the real public EXE URL, and change the button label to “Download for Windows”.
5. Publish the updated `index.html` and test the download from a private/incognito window.

Do not claim the site is public until you complete the hosting steps. This package prepares the site but does not create a hosting account or publish it automatically.
